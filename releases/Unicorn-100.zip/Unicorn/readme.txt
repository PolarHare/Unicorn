Unicorn automatically fills mp3 tags for selected files or all files from folder (recursively).
It uses http://the.echonest.com/ API for recognizing mp3 files.

To run - unzip release archive to any folder, than - launch bin/run.bat script.


Author:           Polyarnyi Nikolay
Build date:       18.06.2014  17:05
Release version:  100